-- Docs: https://docs.mage.ai/guides/sql-blocks
select * from green_nyc_taxi.green_nyc_taxi_data_2020Q4 limit 5;