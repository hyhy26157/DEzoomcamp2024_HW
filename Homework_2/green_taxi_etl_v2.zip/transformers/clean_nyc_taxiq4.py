import re
import numpy as np
import pandas as pd

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

def camel_to_snake(name):
    # Insert an underscore before any uppercase letter that is either followed by a lowercase letter or preceded by neither an uppercase letter nor an underscore, making sure not to add an underscore at the start.
    name = re.sub(r'(?<!^)(?=[A-Z][a-z])|(?<=[a-z])(?=[A-Z])', '_', name)
    return name.lower()

@transformer
def transform(data, *args, **kwargs):
    # num of data removed displayed
    taxi_with_zero_passengers = data['passenger_count'].isin([0]).sum()
    print(f"Preprocessing: rows with zero passengers: {taxi_with_zero_passengers}")
    taxi_with_zero_trip_distance = data['trip_distance'].isin([0]).sum()
    print(f"Preprocessing: rows with zero trip distance: {taxi_with_zero_trip_distance}")
    
    #Camel Case to Snake Case
    data.columns = [camel_to_snake(col) for col in data.columns]

    data['lpep_pickup_date'] = data['lpep_pickup_datetime'].dt.strftime('%Y-%m-%d')
    data['lpep_pickup_month'] = data['lpep_pickup_datetime'].dt.month

    # create date column
    return data[(data['passenger_count'] > 0) 
                & (data['trip_distance'] > 0)
                & (data['lpep_pickup_month'].isin([10,11,12]))
                ]



@test
def test_output(output, *args) -> None:

    # Assertion 1: `vendor_id` is one of the existing values in the column
    assert ((output['vendor_id'].isin([1, 2])) | pd.isnull(output['vendor_id'])).all(), "vendor_id contains invalid values"
    # Assertion 2: `passenger_count` is greater than 0
    assert (output['passenger_count'] > 0).all(), "passenger_count contains values less than or equal to 0"

    # Assertion 3: `trip_distance` is greater than 0
    assert (output['trip_distance'] > 0).all(), "trip_distance contains values less than or equal to 0"
